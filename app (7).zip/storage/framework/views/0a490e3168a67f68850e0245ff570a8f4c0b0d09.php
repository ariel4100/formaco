<?php $__env->startSection('titulo','Productos'); ?>

<?php $__env->startSection('estilo'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/page/equipamiento.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/preguntas.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/subproducto.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('paginas'); ?>
<div class="container-fluid" style="margin: 5% 5%">
<article class="row" >
      <section class="col s12">
        <div class="titulo">
          <?php if($seleccionada->seccion == 'maquinas'): ?>
            Máquinas y Herramientas
          <?php endif; ?>
          <?php if($seleccionada->seccion == 'flejes'): ?>
            Flejes
          <?php endif; ?>
          <?php if($seleccionada->seccion == 'embalaje'): ?>
            Artículos de embalaje
          <?php endif; ?>
          <?php if($seleccionada->seccion == 'sellos'): ?>
            Sellos y hebillas
          <?php endif; ?>
        </div><hr>
      </section>
    </article>
		<div class="row">
			<div class="col s12 m3">
				<div class="row">
					<div class="col s12"  style="padding-left: 0px;">
						
					      <?php if($seleccionada->seccion == 'maquinas'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('maquinas-herramientas')); ?>">TODOS</a>
                          <?php endif; ?>
                          <?php if($seleccionada->seccion == 'flejes'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('flejes')); ?>">TODOS</a>
                          <?php endif; ?>
                          <?php if($seleccionada->seccion == 'embalaje'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('articulos-embalaje')); ?>">TODOS</a>
                          <?php endif; ?>
                          <?php if($seleccionada->seccion == 'sellos'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('sellos-hebillas')); ?>">TODOS</a>
                          <?php endif; ?>
					</div>
				</div>
				<ul id="nav-mobile" class="side-nav fixed" style="position: relative; box-shadow: none; display: inline;">
	        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          <ul class="collapsible collapsible-accordion">
	            <li class="bold"><a href="<?php echo e(route('subproducto',$familia->id)); ?>" class="hover collapsible-header waves-effect waves-admin <?php if($familia->id == $seleccionada->id){?> active <?php } ?>"><?php echo e($familia->nombre); ?><i class="material-icons" style="margin: 0px;">expand_more</i></a>
	              <div class="collapsible-body">
	                <?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfamilia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                  <?php if($subfamilia->id_familia == $familia->id): ?>
	                    <ul>
	                      <li><a class="hover producto <?php if($subfamilia->id == $seleccionada->id){?>active2 <?php } ?>" style="
    height: 40px !important;" href="<?php echo e(route('galeria',$subfamilia->id)); ?>"><?php echo e($subfamilia->titulo); ?></a>
	                       </li>
	                    </ul>
	                  <?php endif; ?>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	              </div>
	            </li>
	          </ul>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
			</div>
			<div class="col s12 m9">
				<?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfamilia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($subfamilia->id_familia == $seleccionada->id): ?>
						<div class="col s12 m4" style="margin-bottom: 3%">
							<a href="<?php echo e(route('galeria',$subfamilia->id)); ?>">
								<div class="cont-producto">
									<div class="row cont-sub" style="margin:0px; position:relative; border: 1px solid #B0B0B0;">
											<img src="<?php echo e(asset($subfamilia->imagen_destacada)); ?>"  style="max-height:100%;"  class="responsive-img" alt="">
											<div class="cont-img-pro">
											</div>
									</div>
									<div class="row" style="margin:0px;">
										<div class="fila">
											<?php echo e($subfamilia->titulo); ?>

										</div>
									</div>
								</div>
							</a>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>