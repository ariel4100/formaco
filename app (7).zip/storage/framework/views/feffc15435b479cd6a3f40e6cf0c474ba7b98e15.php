<?php $__env->startSection('titulo', 'Editar producto'); ?>



<?php $__env->startSection('contenido'); ?>



<main>

	<div class="container">

	    <?php if(count($errors) > 0): ?>

		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">

	  		<ul>

	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	  				<li><?php echo $error; ?></li>

	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  		</ul>

	  	</div>

		<?php endif; ?>

		<?php if(session('success')): ?>

		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">

			<?php echo e(session('success')); ?>


		</div>

		<?php endif; ?>



		<div class="row">

			<div class="col s12">

			<?php echo Form::model($producto, ['route'=>['subproducto.update',$producto->id], 'method'=>'PUT', 'files' => true]); ?>


      <div class="row">

        <div class="form-group col s6">

          <?php echo Form::label('Familia:'); ?>

		  <select name="id_familia" id="id_familia" required>
		  	<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  		<?php if($producto->id_familia == $familia->id): ?>
					<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->nombre); ?></option>
				<?php endif; ?>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  	<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  		<?php if($producto->id_familia != $familia->id): ?>
					<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->nombre); ?></option>
				<?php endif; ?>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </select>
        </div>

      </div>

		<div class="file-field input-field col s12">
			<div class="btn">
					<span>Imagen</span>
					<?php echo Form::file('imagen_destacada'); ?>

			</div>
			<div class="file-path-wrapper">
					<?php echo Form::text('imagen_destacada',$producto->imagen, ['class'=>'file-path validate', 'required']); ?>

			</div>
      	</div>

        <div class="row">
          <label class="col s12" for="parrafo">Contenido</label>
          <div class="input-field col s12">
            <?php echo Form::textarea('contenido', $producto->contenido, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

          </div>
        </div>

				<div class="row">

					<div class="input-field col s6">

						<?php echo Form::label('Nombre:'); ?>


						<?php echo Form::text('titulo', $producto->titulo , ['class'=>'validate', 'required']); ?>


					</div>

          <div class="input-field col s6">

            <?php echo Form::label('Orden:'); ?>


            <?php echo Form::text('orden', $producto->orden , ['class'=>'validate', 'required']); ?>


          </div>
          <div class="input-field col s6">
            <?php echo Form::label('Link de video:'); ?>

            <?php echo Form::text('link', $producto->link , ['class'=>'validate']); ?>

          </div>

				</div>

        <div class="file-field input-field col s12">

        <div class="btn">

						<span>Archivo para descarga</span>

						<?php echo Form::file('descarga'); ?>


				</div>

				<div class="file-path-wrapper">

						<?php echo Form::text('descarga',$producto->descarga, ['class'=>'file-path validate']); ?>


				</div>

        </div>
		<div class="row">

	        <div class="form-group col s6">

	          <?php echo Form::label('Por cual fleje desea que sea buscado:'); ?>

			  <select name="flejar" id="flejar" required>
		  		<?php if($producto->flejar == null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  	<?php $__currentLoopData = $flejes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->flejar == $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php $__currentLoopData = $flejes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->flejar != $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php if($producto->flejar != null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  </select>
	        </div>

     	 </div>
     	 <div class="row">

	        <div class="form-group col s6">

	          <?php echo Form::label('Por cuál sistema de fleje desea que sea buscado? : '); ?>

			  <select name="sistema" id="sistema" required>
  		  		<?php if($producto->sistema == null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  	<?php $__currentLoopData = $sistema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->sistema == $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php $__currentLoopData = $sistema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->sistema != $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php if($producto->sistema != null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  </select>
	        </div>

     	 </div>
     	 <div class="row">

	        <div class="form-group col s6">

	          <?php echo Form::label('Por cual tipo de fleje desea que sea buscado?: '); ?>

			  <select name="tipo" id="tipo" required>
			  	<?php if($producto->tipo == null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  	<?php $__currentLoopData = $tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->tipo == $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php $__currentLoopData = $tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->tipo != $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php if($producto->tipo != null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  </select>
	        </div>

     	 </div>
     	 <div class="row">

	        <div class="form-group col s6">

	          <?php echo Form::label('Por qué cantidad de fleje desea que sea buscado? : '); ?>

			  <select name="cantidad" id="cantidad" required>
			  	<?php if($producto->cantidad == null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  	<?php $__currentLoopData = $cantidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->cantidad == $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php $__currentLoopData = $cantidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<?php if($producto->cantidad != $familia->id): ?>
						<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->texto); ?></option>
					<?php endif; ?>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php if($producto->cantidad != null): ?>
					<option value="0">Ninguno</option>
				<?php endif; ?>
			  </select>
	        </div>

     	 </div>
				<div class="col s12 no-padding">

					<?php echo Form::submit('Actualizar', ['class'=>'waves-effect waves-light btn right']); ?>


				</div>

			<?php echo Form::close(); ?>




		</div>

	</div>

</main>



<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>

<script>

	CKEDITOR.replace('contenido');

  CKEDITOR.replace('tabla');

	CKEDITOR.config.height = '150px';

	CKEDITOR.config.width = '100%';

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>