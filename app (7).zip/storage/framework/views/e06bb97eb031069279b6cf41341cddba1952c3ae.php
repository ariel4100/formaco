<?php $__env->startSection('titulo','Novedades'); ?>



<?php $__env->startSection('estilo'); ?>



	<link rel="stylesheet" href="<?php echo e(asset('css/page/servicio.css')); ?>">



	<link rel="stylesheet" href="<?php echo e(asset('css/page/slider.css')); ?>">




<?php $__env->stopSection(); ?>


<?php $__env->startSection('paginas'); ?>
<?php
		$inicio = 'Inicio';
		$noticias = 'Actualidad';
		$buscar_input = 'Buscar';
?>
    <div class="contenedor centro-novedades   fondodestacados  margenfoot" id="pos"  style="margin:5% 6%;">
      <div class="row margindestacados">
      <div class="col s12 migas">
        <a href="<?php echo e(route('novedades')); ?>" >
         Novedades
       </a> | <a href="<?php echo e(route('buscarnove.show',$categorianove->id)); ?>"><?php echo e($categorianove->nombre); ?> </a> | <?php echo e($novedad->nombre); ?>

      </div>
       <div class="col s12 col m9 " >
            <div class="col s12 titular_listado_novedades" style="padding-left: 1px; margin-bottom: 2%;">
              <span class="Nombre_novedad fuenteRC">
                <?php echo e(strtoupper($categorianove->nombre )); ?>

              </span>
            </div>
            <div class="col-xs-12 " style="padding-left: 1px;">
              <img style="width: 100%;" src="<?php echo e(asset($novedad->imagen_maxi)); ?>" class="img-responsive imgnovedades"  alt="imagen">
            </div>
            
            <div class="col s12 " style="padding-left: 1px;" >
              <p class="novedadesfecha"><?php echo e($novedad->fecha); ?></p>
              <p class="novedadestitulo fuenteRC"><?php echo e($novedad->nombre); ?></p>
              <div class="novedadesbreve"><?php echo $novedad->texto; ?></div>
              
              
            </div>
            <?php if($novedad->ficha): ?>
            <div class="col s12" style="margin-top: 25px; padding: 0px;">
              <a href="<?php echo e($novedad->ficha); ?>" target="_blank" class=" btn-descarga" download>
              Descargar PDF
              </a>
            </div>
            <?php endif; ?>
      </div>
      <div class="col s12 col m3 buscadorfiltrador">
        <div class="col s12 nopadding" style="padding-bottom:10px; ">
              <form action="<?php echo e(route('buscarnove.store')); ?>" class="buscador_noticias" method="POST">
              <?php echo e(csrf_field()); ?>

                  <input placeholder="<?php echo e($buscar_input); ?>" name="busca" class="buscador2" type="text">
              </form>
        </div>
              <div class="categorias fuenteRC">
                <a href="<?php echo e(route('novedades')); ?>"><p>Categorías</p></a>
              </div>
              <div class="col s12" style="padding-left: 1px;">
              <?php $__currentLoopData = $categorias2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="<?php echo e(route('buscarnove.show',$categoria2->id)); ?>" style="text-decoration:none !important;"><li class="tagcategoria fuenteRC">»<?php echo e($categoria2->nombre); ?></li></a>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
      </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>