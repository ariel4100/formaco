

<?php $__env->startSection('titulo', 'Editar Empresa'); ?>

<?php $__env->startSection('contenido'); ?>
<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
			<?php echo Form::model($contenido, ['route'=>['contenido.update',$contenido->id], 'method'=>'PUT', 'files' => true]); ?>

				<div class="row">
					<div class="file-field input-field col s12">
						<div class="btn">
						    <span>Imagen de empresa</span>
						    <?php echo Form::file('imagen'); ?>

						</div>
						<div class="file-path-wrapper">
						    <?php echo Form::text('imagen',null, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Titulo:'); ?>

						<?php echo Form::text('titulo', $contenido->titulo , ['class'=>'validate', 'required']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Subtitulo:'); ?>

						<?php echo Form::text('subtitulo', $contenido->subtitulo , ['class'=>'validate']); ?>

					</div>
			    <label class="col s12" for="parrafo">Contenido</label>
		      <div class="input-field col s12">
						<?php echo Form::textarea('contenido', $contenido->contenido, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

			    </div>
				</div>
				<div class="col s12 no-padding">
					<?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
			<?php echo Form::close(); ?>

			</div>
			</div>
		</div>
	</main>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	CKEDITOR.replace('contenido');
	CKEDITOR.config.height = '150px';
	CKEDITOR.config.width = '100%';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>