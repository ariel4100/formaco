<?php $__env->startSection('titulo','Formaco | Buscador'); ?>
<?php $__env->startSection('estilo'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/page/equipamiento.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/preguntas.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('paginas'); ?>
<div class="container-fluid" style="margin: 5% 10%;">
	<div class="row">

		<?php if($productos!=null): ?>
			<?php $__currentLoopData = $subproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfamilia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col s12 m4" style="margin-bottom: 3%">
						<a href="<?php echo e(route('galeria',$subfamilia->id)); ?>">
							<div class="cont-producto" style="height: 415px;">
								<div class="row cont-sub" style="margin:0px; position:relative; height:350px;">
										<img style="max-height: 350px;" src="<?php echo e(asset($subfamilia->imagen_destacada)); ?>" class="responsive-img" alt="">
										<div class="cont-img-pro">
										</div>
								</div>
								<div class="row" style="margin:0px;">
									<div class="fila">
										<?php echo e($subfamilia->titulo); ?>

									</div>
								</div>
							</div>
						</a>
					</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>