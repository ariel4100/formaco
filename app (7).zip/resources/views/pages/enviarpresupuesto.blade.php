<!DOCTYPE html>
<html>
<body>
	<h2>Cercas</h2>
	<p>Enviado desde la web Cercas.</p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong> {{$nombre}}</li>
		<li><strong>Email:</strong> {{$email}}</li>
		<li><strong>Localidad:</strong> {{$localidad}}</li>
		<li><strong>Telefono:</strong> {{$telefono}}</li>
		<li><strong>Plano:</strong> {{$plano}}</li>
		
	</ul>
	<br>
	<br>
	<h4>Mensaje:</h4>
	<p>{{$mensaje}}</p>
</body>
</html>