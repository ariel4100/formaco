@extends('adm.cuerpo')

@section('titulo','Bienvenido al administrador, HEISOL.')
