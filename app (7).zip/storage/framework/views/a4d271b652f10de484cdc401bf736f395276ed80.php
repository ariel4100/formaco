<?php $__env->startSection('titulo', 'Sectores'); ?>
<?php $__env->startSection('estilo'); ?>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/russo-styles.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/preguntas.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/subproducto.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginas'); ?>
  <section class="container-fluid" style="margin: 5% 5%">
	<article class="row" >
      <section class="col s12">
        <div class="titulo">
          Soluciones por Sector
        </div><hr>
      </section>
    </article>
    <div class="row">
    	<div class="col s12">
    		<p>
	    		Haga click en los distintos grupos y sectores para conocer el listado de productos especializado. 
	    	</p>
    	</div>
    </div>
    <div class="row" style="padding: 0px 10%">
    	<?php $__currentLoopData = $sectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<div class="col s12 m3 sector">
	    		<a href="<?php echo e(route('sectores', $sector->id)); ?>" style="color: #A6A6A6;">
	    			<div style="text-align: center;">
		    			<img src="<?php echo e(asset($sector->imagen)); ?>" alt="">
		    		</div>
		    		<div style="text-align: center;">
		    			<?php echo e($sector->nombre); ?>

		    		</div>
	    		</a>
	    	</div>
	    	
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row subsectores">
    	<p class="center" style="color: #04599B; font-weight: 600; margin-bottom: 5%;">Seleccione Subsección</p>
    	<?php $__currentLoopData = $subsectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<a href="<?php echo e(route('subsectores', $subsector->id)); ?>" style="color: #A6A6A6;">
	    		<div class="col s12 m4 subsector" onclick="ajax($$subsector->id)">
					<div style="text-align: center;">
		    			<img src="<?php echo e(asset($subsector->imagen)); ?>" alt="">
		    		</div>
		    		<div style="text-align: center;">
		    			<?php echo e($subsector->nombre); ?>

		    		</div>
				</div>
	    	</a>
			
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<script>
	function ajax($id){
		$.ajax({
			url: "demo_test.txt", 
			success: function(result){
		        // $("#div1").html(result);
		        console.log(result);
		    }
		});
	}
</script>
<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>