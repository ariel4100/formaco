

<?php $__env->startSection('titulo', 'Editar metadatos de '. $metadatos->seccion); ?>

<?php $__env->startSection('contenido'); ?>

<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
			<?php echo Form::model($metadatos, ['route'=>['metadatos.update',$metadatos->id], 'method'=>'PUT', 'files' => true]); ?>	
				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('keywords', 'Keywords'  ); ?>

						<?php echo Form::text('keywords', $metadatos->keywords, ['class' => 'validate', 'placeholder' => 'Aquí puede escribir palabras claves sobre esta sección']); ?>

					</div>
					
					<div class="input-field col s6">
						<?php echo Form::label('description', 'Descripción'); ?>

						<?php echo Form::text('description', $metadatos->description, ['class' => 'validate', 'required']); ?>

					</div>
					
				</div>
				<div class="col s12 no-padding">
					<?php echo Form::submit('Actualizar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
			<?php echo Form::close(); ?> 
			</div>
		</div>
	</div>
</main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>