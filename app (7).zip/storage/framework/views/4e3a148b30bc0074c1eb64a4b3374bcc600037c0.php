<?php $__env->startSection('titulo','Buscador de productos'); ?>

<?php $__env->startSection('estilo'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/page/servicio.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/page/slider.css')); ?>">

<?php $__env->startSection('paginas'); ?>
	<div class="contenedor centro-novedades   fondodestacados margen-top margenfoot" id="pos" style="margin:5% 6%;">
		<div class="row margindestacados">
			<div class="col s12 titulonove">
				Buscador de Productos<hr>
			</div>
			<p class="center">Selecciones las opciones para recibir asesoramiento inmediato en línea, es fácil y rápido.</p>
		</div>
		<div class="row" style="padding: 0px 8%; text-align: center;">
			<?php echo Form::open(['route' => 'buscar_opciones', 'method' => 'POST', 'id'=>'buscador']); ?>

			<div class="col s12 m3">
				<div class="row">
					<div class="col s12">
						<p style="color:#00589E;">	
							¿Qué producto quiere Flejar?
						</p>
					</div>
					
				</div>
				<?php $__currentLoopData = $buscadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($buscador->seccion == "flejar"): ?>
						<div class="row">
							<div class="col s12">
							
								<p>
									<input type="radio" id="<?php echo e($buscador->id); ?>" name="flejar" value="<?php echo e($buscador->id); ?>">
									<label for="<?php echo e($buscador->id); ?>"><?php echo e($buscador->texto); ?></label>
								</p>
								
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="col s12 m3">
				<div class="row">
					<div class="col s12">
						<p style="color:#00589E;">
							 Sistema de flejado
						</p>
					</div>
				</div>
				<?php $__currentLoopData = $buscadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($buscador->seccion == "sistema"): ?>
						<div class="row">
							<div class="col s12">
							
								<p>
									<input type="radio" id="<?php echo e($buscador->id); ?>" name="sistema" value="<?php echo e($buscador->id); ?>">
									<label for="<?php echo e($buscador->id); ?>"><?php echo e($buscador->texto); ?></label>
								</p>
								
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="col s12 m3">
				<div class="row">
					<div class="col s12">
						<p style="color:#00589E;">
							 Tipo de Fleje
						</p>
					</div>
				</div>
				<?php $__currentLoopData = $buscadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($buscador->seccion == "tipo"): ?>
						<div class="row">
							<div class="col s12">
							
								<p>
									<input type="radio" id="<?php echo e($buscador->id); ?>" name="tipo" value="<?php echo e($buscador->id); ?>">
									<label for="<?php echo e($buscador->id); ?>"><?php echo e($buscador->texto); ?></label>
								</p>
								
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="col s12 m3">
				<div class="row">
					<div class="col s12">
						<p style="color:#00589E;">
							Cantidad cada 24 Hs
						</p>
					</div>
				</div>
				<?php $__currentLoopData = $buscadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($buscador->seccion == "cantidad"): ?>
						<div class="row">
							<div class="col s12">
							
								<p>
									<input type="radio" id="<?php echo e($buscador->id); ?>" name="cantidad" value="<?php echo e($buscador->id); ?>">
									<label for="<?php echo e($buscador->id); ?>"><?php echo e($buscador->texto); ?></label>
								</p>
								
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			
			
			<div class="col s12" style="margin-top: 50px;">
				<button type ="submit" class="waves-effect waves-light btn" style="text-align: center; margin-bottom: 7%;">
					Buscador
				</button>
	    	</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>