

<?php $__env->startSection('titulo', 'Editar Novedad'); ?>

<?php $__env->startSection('contenido'); ?>

<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
			<?php echo Form::model($novedad,['route'=>['novedades.update',$novedad->id], 'method'=>'PUT', 'files' => true]); ?>


				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('Titulo :'); ?>

						<?php echo Form::text('nombre', $novedad->nombre , ['class'=>'validate', 'required']); ?>

					</div>
					<div class="file-field input-field col s12">
						<div class="btn">
						    <span> Imagen (Tamaño recomendado 403x223) </span>
						    <?php echo Form::file('imagen'); ?>

						</div>
						<div class="file-path-wrapper">
						    <?php echo Form::text('imagen',$novedad->imagen, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="file-field input-field col s12">
						<div class="btn">
						    <span>Imagen (novedad)(Tamaño recomendado 847x468)</span>
						    <?php echo Form::file('imagen_maxi'); ?>

						</div>
						<div class="file-path-wrapper">
						    <?php echo Form::text('imagen_maxi',$novedad->imagen_maxi, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="file-field input-field col s12">
						<div class="btn">
						    <span>Archivo PDF</span>
						    <?php echo Form::file('ficha'); ?>

						</div>
						<div class="file-path-wrapper">
						    <?php echo Form::text('ficha',$novedad->ficha, ['class'=>'file-path validate']); ?>

						</div>
					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Orden:'); ?>

						<?php echo Form::text('orden', $novedad->orden , ['class'=>'validate', 'required']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Fecha:'); ?>

						<?php echo Form::text('fecha', $novedad->fecha , ['class'=>'validate', 'required']); ?>

					</div>
					<label class="col s12" for="parrafo">Texto</label>
			      	<div class="input-field col s12">
						<?php echo Form::textarea('texto', $novedad->texto, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

				    </div>
						<label class="col s12" for="parrafo">Texto breve</label>
				      	<div class="input-field col s12">
							<?php echo Form::textarea('texto_breve', $novedad->texto_breve, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

					    </div>
				</div>
				<div class="col s12 no-padding">
					<?php echo Form::submit('Crear', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	CKEDITOR.replace('texto');
	CKEDITOR.replace('texto_breve');
	CKEDITOR.config.height = '150px';
	CKEDITOR.config.width = '100%';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>