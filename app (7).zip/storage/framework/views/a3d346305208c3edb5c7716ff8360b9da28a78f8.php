

<?php $__env->startSection('titulo', 'Crear Subsector'); ?>

<?php $__env->startSection('contenido'); ?>

<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
			<?php echo Form::open(['route'=>['subsectores.store'], 'method'=>'POST', 'files' => true]); ?>

				
		       	<?php echo e(csrf_field()); ?>

				<div class="row">
					<div class="form-group col-xs-12 pad-panel">
					  <?php echo Form::label('Familia:'); ?>

					  <?php echo Form::select('id_sector', $familias, null, ['class' => 'form-control']); ?>

					</div>
				</div>
				<div class="file-field input-field col s12">
					<div class="btn">
							<span>Imagen</span>
							<?php echo Form::file('imagen'); ?>

					</div>
					<div class="file-path-wrapper">
							<?php echo Form::text('imagen',null, ['class'=>'file-path validate', 'required']); ?>

					</div>
	        	</div>
		        <div class="row">
		          <div class="input-field col s6">
		            <?php echo Form::label('Nombre:'); ?>

		            <?php echo Form::text('nombre', null , ['class'=>'validate', 'required']); ?>

		          </div>
		          <div class="input-field col s6">
		            <?php echo Form::label('Orden:'); ?>

		            <?php echo Form::text('orden', null , ['class'=>'validate', 'required']); ?>

		          </div>
		        </div>
		        <div class="row">
					<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<p>
							<input type="checkbox" id="<?php echo e($producto->id); ?>" name="producto[]" value="<?php echo e($producto->id); ?>" />
							<label for="<?php echo e($producto->id); ?>"><?php echo e($producto->titulo); ?></label>
						</p>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="col s12 no-padding">
					<?php echo Form::submit('Actualizar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>