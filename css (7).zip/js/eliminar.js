
	function confirm_delete(formObj) { 

	    if(confirm("Esta seguro que desea elminar este elemento?")) { 
	 		return true;
	    }else{
	    	return false;
	    }

	}