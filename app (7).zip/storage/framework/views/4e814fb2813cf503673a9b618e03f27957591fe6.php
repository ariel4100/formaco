﻿
<?php $__env->startSection('titulo', 'Productos'); ?>
<?php $__env->startSection('estilo'); ?>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/russo-styles.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/preguntas.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/subproducto.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginas'); ?>
  <section class="container-fluid" style="margin: 5% 5%">
		<article class="row" >
      <section class="col s12">
        <div class="titulo">
          <?php echo e($titulo); ?>

        </div><hr>
      </section>
    </article>
	<div class="row">
		<div class="col s12 m3">
			<div class="row">
				<div class="col s12" style="padding-left: 0px;">
			
					<?php if($titulo == 'maquinas'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('maquinas-herramientas')); ?>">TODOS</a>
                          <?php endif; ?>
                          <?php if($titulo == 'flejes'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('flejes')); ?>">TODOS</a>
                          <?php endif; ?>
                          <?php if($titulo == 'embalaje'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('articulos-embalaje')); ?>">TODOS</a>
                          <?php endif; ?>
                          <?php if($titulo == 'sellos'): ?>
                            <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('sellos-hebillas')); ?>">TODOS</a>
                          <?php endif; ?>
				</div>
			</div>
				<ul id="nav-mobile" class="side-nav fixed" style="position: relative; box-shadow: none; display: inline;">
	     <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          <ul class="collapsible collapsible-accordion">
	            <li class="bold"><a href="<?php echo e(route('subproducto',$familia->id)); ?>" class="hover collapsible-header waves-effect waves-admin"><i class="material-icons" style="margin: 0px;">expand_more</i><?php echo e($familia->nombre); ?></a>
	              <div class="collapsible-body">
	                <?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfamilia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                  <?php if($subfamilia->id_familia == $familia->id): ?>
	                    <ul>
	                      <li><a class="hover producto" href="<?php echo e(route('galeria',$subfamilia->id)); ?>"><?php echo e($subfamilia->titulo); ?></a>
	                       </li>
	                    </ul>
	                  <?php endif; ?>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	              </div>
	            </li>
	          </ul>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
			</div>
			<div class="col s12 m8">
				<div class="row">
					<?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col s12 m4" style="margin-bottom: 3%">
						<a href="<?php echo e(route('subproducto',$producto->id_familia)); ?>">
							<div class="cont-producto">
								<div class="row" style="  border: 1px solid #B0B0B0; margin:0px; position:relative; height: 260px; display: flex; justify-content: center;align-content: center;">
										<img src="<?php echo e(asset($producto->imagen_destacada)); ?>"  style="max-height:100%;"  class="responsive-img" alt="">
										<div class="cont-img-pro">

										</div>
								</div>
								<div class="row" style="margin:0px;">
									<div class="fila">
										<?php echo e($producto->titulo); ?>

									</div>
									<div class="parrafo_corto" style="height:80px;
    overflow:hidden;
    text-overflow: ellipsis;">
										<?php echo $producto->contenido; ?> 
									</div>
								</div>
							</div>
						</a>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		
	</div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>