<?php $__env->startSection('titulo', 'Galeria'); ?>

<?php $__env->startSection('estilo'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/page/equipamiento.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/subproducto.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/preguntas.css')); ?>">
  <script>
      function actualizar(imagen){
        document.getElementById('producto').src = imagen;
      }
  </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginas'); ?>

  <section class="container-fluid" style="margin: 5% 5%;">
    <article class="row" >
      <section class="col s12">
        <div class="titulo">
          <?php if($seleccionada->seccion == 'maquinas'): ?>
            Máquinas y Herramientas
          <?php endif; ?>
          <?php if($seleccionada->seccion == 'flejes'): ?>
            Flejes
          <?php endif; ?>
          <?php if($seleccionada->seccion == 'embalaje'): ?>
            Artículos de embalaje
          <?php endif; ?>
          <?php if($seleccionada->seccion == 'sellos'): ?>
            Sellos y hebillas
          <?php endif; ?>
        </div><hr>
      </section>
    </article>
    <div class="row">
      <div class="col s12 m3">
        <div class="row">
          <div class="col s12"  style="padding-left: 0px;">

            
            <?php if($seleccionada->seccion == 'maquinas'): ?>
                <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('maquinas-herramientas')); ?>">TODOS</a>
              <?php endif; ?>
              <?php if($seleccionada->seccion == 'flejes'): ?>
                <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('flejes')); ?>">TODOS</a>
              <?php endif; ?>
              <?php if($seleccionada->seccion == 'embalaje'): ?>
                <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('articulos-embalaje')); ?>">TODOS</a>
              <?php endif; ?>
              <?php if($seleccionada->seccion == 'sellos'): ?>
                <a style="color: #A6A6A6; font-weight: 500;" href="<?php echo e(route('sellos-hebillas')); ?>">TODOS</a>
              <?php endif; ?>
            
          </div>
        </div>
				<ul id="nav-mobile" class="side-nav fixed" style="position: relative; box-shadow: none; display: inline;">
	        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          <ul class="collapsible collapsible-accordion">
	            <li class="bold"><a class="hover collapsible-header waves-effect waves-admin <?php if($familia->id == $seleccionada->id_familia){?> active <?php } ?>"><?php echo e($familia->nombre); ?><i class="material-icons" style="margin: 0px;">expand_more</i></a>
	              <div class="collapsible-body">
	                <?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfamilia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                  <?php if($subfamilia->id_familia == $familia->id): ?>
	                    <ul>
	                      <li><a class="hover producto <?php if($subfamilia->id == $seleccionada->id){?>active2 <?php } ?>" href="<?php echo e(route("galeria",$subfamilia->id)); ?>"><?php echo e($subfamilia->titulo); ?></a>
	                       </li>
	                    </ul>
	                  <?php endif; ?>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	              </div>
	            </li>
	          </ul>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
			</div>
      <div class="col s12 m4">
        <?php $i=0 ?>
        <?php $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i==0): ?>
                <div class="galeria center hide-on-small-only">
                    <img class="responsive-img" id="producto" style="max-height:100%;" src="<?php echo e(asset($galeria->imagen)); ?>" alt="">
                </div>
                <?php $i++; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="margin-top: 10px;">
            <?php $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col s12 m4" style="padding-left:0px;">
                    <div class="center height-mini">
                        <img class="responsive-img" src="<?php echo e(asset($galeria->imagen)); ?>" style="max-height:100%;" alt="" onclick="actualizar('<?php echo e(asset($galeria->imagen)); ?>')">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="col s12 m5">
          <div class="titulo-pro"><?php echo e($seleccionada->titulo); ?></div>
          <div class="contenido-pro">
              <?php echo $seleccionada->contenido; ?>

          </div>
          <?php if( $seleccionada->descarga  ): ?>
          <div class="button-des" style="margin-bottom: 5px;">
              <a href="<?php echo e(asset($seleccionada->descarga)); ?>" download="<?php echo e($seleccionada->descarga); ?>">
                  FICHA TÉCNICA
              </a>
          </div>
          <?php endif; ?>
          <div class="button-des">
              <a href="<?php echo e(route('contacto')); ?>" >
                  CONSULTAR
              </a>
          </div>
      </div>

    </div>
    <?php if($seleccionada->link): ?><div class="row">
      <div class="col s3"></div>
      <div class="col s8">
        <div class="row" style="background-color: #EEEEEE; padding: 15px;">
          <div class="col s6">
            <div style="color: #04599B; font-size: 25px; font-weight: 600; margin-top: 32%;">Para más información, <br>
            mirá el video a continuación</div>
          </div>
          <div class="col s6">
            <iframe width="100%" height="315"
              src="<?php echo e($seleccionada->link); ?>">
              </iframe>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
  <section class="row">
      <div>
        
        <div class="col s3"></div>
        <div class="col s9" style="padding: 0px;">
          <div><p class="titulo-servicio">Productos Relacionados</p></div><hr>
          <div class="row">
            <?php ($i=0); ?>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i < 3): ?>
              <div class="col s12 m6 l4" style="padding-left: 0px;">
                <div class="row div_hover">
                  <a href="<?php echo e($producto->link); ?>">
                    <div class="cont-producto">
                      <div class="row" style="    border: 1px solid #B0B0B0; height: 260px !important; border: 1px solid #B0B0B0; margin:0px; position:relative; height: 300px; display: flex; justify-content: center;align-content: center;">
                          <img src="<?php echo e(asset($producto->imagen)); ?>"  style="max-height:100%;"  class="responsive-img" alt="">
                          <div class="cont-img-pro">

                          </div>
                      </div>
                      <div class="row" style="margin:0px;">
                        <div class="fila">
                          <?php echo $producto->nombre; ?>

                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            <?php ($i++); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        
      </div>
    </section>
  </section>

<script>
  $('table').addClass('striped');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>