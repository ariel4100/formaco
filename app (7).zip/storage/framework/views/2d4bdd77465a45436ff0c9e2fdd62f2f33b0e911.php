<?php $__env->startSection('titulo','Novedades'); ?>

<?php $__env->startSection('estilo'); ?>

	<link rel="stylesheet" href="<?php echo e(asset('css/page/servicio.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('css/page/slider.css')); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginas'); ?>
<?php

		$inicio = 'Inicio';

		$noticias = 'Actualidad';

			$buscar_input = 'Buscar';

?>

	<div class="contenedor centro-novedades   fondodestacados margen-top margenfoot" id="pos" style="margin:5% 6%;">
		<div class="row margindestacados">
		<div class="col s12 titulonove">
				Últimas noticias<hr>
		</div>
		<div class="col s12 col m9 " >
		<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $novedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($novedad->id_categoria == $categoria->id): ?>
				<a href="<?php echo e(route('novedad',$novedad->id)); ?>" style="text-decoration: none">
				<div class="col s12" style="margin-bottom: 6%;">
				<div class="row">
					<div class="col s12 titular_listado_novedades" style="padding-left: 1px; margin-bottom: 2%;">
						<span class="Nombre_novedad fuenteRC">
							<?php echo e(strtoupper($categoria->nombre )); ?>

						</span>
					</div>
					<div class="col s12 m6 " style="padding-left: 1px;">
						<img style="width: 100%;" src="<?php echo e(asset($novedad->imagen)); ?>" class="img-responsive imgnovedades"  alt="imagen">
					</div>
					
					<div class="col s12 m6 " style="padding-left: 1px;" >
						<p class="novedadesfecha"><?php echo e($novedad->fecha); ?></p>
						<p class="novedadestitulo fuenteRC"><?php echo e($novedad->nombre); ?></p>
						<div class="novedadesbreve"><?php echo $novedad->texto_breve; ?></div>
						<a href="<?php echo e(route('novedad',$novedad->id)); ?>" class=" btn-nove">
							Leer más»
						</a>
					</div>
					</div>
				</div>
				</a>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>   <!-- ******************************************************* Columna1 -->
		<div class="col s12 col m3 buscadorfiltrador">
			<div class="col s12 nopadding" style="padding-bottom:10px; ">
						<form action="<?php echo e(route('buscarnove.store')); ?>"  method="POST">
						<?php echo e(csrf_field()); ?>

								<input type="text" placeholder="<?php echo e($buscar_input); ?>" name="busca" class="buscador2" >
						</form>
			</div>
						<div class=" categorias fuenteRC">

							<a href="<?php echo e(route('novedades')); ?>"><p>
									Categorias
							</p></a>
						</div>
						<div class="col s12" style="padding-left: 1px;">
						<?php $__currentLoopData = $categorias2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(route('buscarnove.show',$categoria2->id)); ?>" style="text-decoration:none !important;"><li class="tagcategoria fuenteRC">»<?php echo e($categoria2->nombre); ?></li></a>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
		</div>

	</div>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>