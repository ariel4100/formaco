<!DOCTYPE html>

<html lang="en">

<head>

	<meta charset="UTF-8">

	<title><?php echo $__env->yieldContent('titulo'); ?></title>

	<meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?php echo e(asset('plugins/materialize/css/materialize.min.css')); ?>">

    <link rel="icon" type="image/png" href="<?php echo e(asset($favicon->ruta)); ?>"/>

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <meta name="keywords" content="<?php echo e($metadatos->keywords); ?>">

    <meta name="description" content="<?php echo e($metadatos->description); ?>">

    <script src="<?php echo e(asset('plugins/materialize/js/jquery.min.js')); ?>"></script>

    <!-- Materialize Core JavaScript -->

    <script src="<?php echo e(asset('plugins/materialize/js/materialize.min.js')); ?>"></script>



    <!--Estilos propios-->

    <link rel="stylesheet" href="<?php echo e(asset('css/header-footer.css')); ?>">

    <?php echo $__env->yieldContent('estilo'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>">

    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"> 
</head>

<body>

    <?php echo $__env->make('pages.templates.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <main><?php echo $__env->yieldContent('paginas'); ?></main>

    <?php echo $__env->make('pages.templates.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script>

        $(".button-collapse").sideNav()

    </script>

    <script>

        $('.carousel.carousel-slider').carousel({fullWidth: true});

    </script>



<!--End of Tawk.to Script-->
</body>

</html>
