<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p>{{ $mensaje }}</p>
    <ul>
        <li>Nombre: {{ $nombre }}</li>
        <li>Apellido: {{ $apellido }}</li>
        <li>Empresa: {{ $empresa }}</li>
        <li>Email: {{ $email }}</li>
    </ul>
</body>
</html>