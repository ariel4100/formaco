<?php $__env->startSection('titulo', 'FORMACO'); ?>
<?php $__env->startSection('estilo'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/page/slider.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/page/home.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/page/preguntas.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginas'); ?>
	<div class="container-fluid">
		<div id="carousel" class="carousel carousel-slider center" data-indicators="true" style="position: relative;">
		    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <div class="carousel-item white-text" href="" style="position: absolute;">
			      <img src="<?php echo e(asset($slider->imagen)); ?>" alt="">
			      <?php if($slider->titulo): ?>
			      	<div class="cont-titulos">
				    	<div>
				    		<div class="titulo-slider "><?php echo $slider->titulo; ?></div>
							<div class="subtitulo-slider "><?php echo $slider->subtitulo; ?></div>
				    		<div style="text-align: center; margin-bottom: 7%;">
								<a class="waves-effect waves-light btn" href="<?php echo e(route('buscador-productos')); ?>">Buscador</a>
					    	</div>
				    	</div>
				    	
				    </div>
				   <?php endif; ?>
			    </div>
			    <div class="expand"><a href="#empresa"><i class="material-icons hide-on-small-only" style="color:white;">expand_more</i></a></div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<section class="row" style="margin-top: 40px;">
			<div style="margin: 0px 6%;">
				<div style="margin-bottom: 3%;"><p class="titulo-servicio">Productos Destacados</p><hr></div>
				<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col s12 m6 l3">
						<div class="row div_hover">
							<a href="<?php echo e($producto->link); ?>">
								<div>
									<div class="row" style="  border: 1px solid #B0B0B0; margin:0px; position:relative; height: 300px; display: flex; justify-content: center;align-content: center;">
											<img src="<?php echo e(asset($producto->imagen)); ?>"  style="max-height:100%;"  class="responsive-img" alt="">
											<div class="cont-img-pro">

											</div>
									</div>
									<div class="row" style="margin:0px;">
										<div class="destacado">
											<?php echo $producto->nombre; ?>

										</div>
									</div>
									<div class="row descripcion-producto-destacado">
										<?php echo $producto->descripcion; ?>

									</div>
								</div>
							</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</section>
		<section class="container-fluid gray row" style="margin-bottom: 0px">
			<div class="col s12">
				<div class="row center">
					<img src="<?php echo e(asset($home->imagen)); ?>" alt="">
				</div>
			</div>
			<div class="col s12">
				
				<div class="title-home ">
					<?php echo $home->titulo; ?>

				</div>
				<div class="content-home ">
					<?php echo $home->contenido; ?>

				</div>
				
			</div>
			
		</section>
	</div>
	<script>
		  $(document).ready(function(){
		    $('.parallax').parallax();
		  });
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>