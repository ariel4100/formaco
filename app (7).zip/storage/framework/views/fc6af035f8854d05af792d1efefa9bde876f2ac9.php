



<?php $__env->startSection('titulo', 'Editar subsector'); ?>



<?php $__env->startSection('contenido'); ?>



<main>

	<div class="container">

	    <?php if(count($errors) > 0): ?>

		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">

	  		<ul>

	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	  				<li><?php echo $error; ?></li>

	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  		</ul>

	  	</div>

		<?php endif; ?>

		<?php if(session('success')): ?>

		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">

			<?php echo e(session('success')); ?>


		</div>

		<?php endif; ?>



		<div class="row">

			<div class="col s12">

			<?php echo Form::model($producto, ['route'=>['subsectores.update',$producto->id], 'method'=>'PUT', 'files' => true]); ?>


      <div class="row">

        <div class="form-group col s6">

          <?php echo Form::label('Sector:'); ?>

		  <select name="id_sector" id="id_sector" required>
		  	<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  		<?php if($producto->id_sector == $familia->id): ?>
					<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->nombre); ?></option>
				<?php endif; ?>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  	<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  		<?php if($producto->id_sector != $familia->id): ?>
					<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->nombre); ?></option>
				<?php endif; ?>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </select>
        </div>

      </div>

		<div class="file-field input-field col s12">
			<div class="btn">
					<span>Imagen</span>
					<?php echo Form::file('imagen'); ?>

			</div>
			<div class="file-path-wrapper">
					<?php echo Form::text('imagen',$producto->imagen, ['class'=>'file-path validate', 'required']); ?>

			</div>
      	</div>

		<div class="row">

			<div class="input-field col s6">

				<?php echo Form::label('Nombre:'); ?>


				<?php echo Form::text('nombre', $producto->titulo , ['class'=>'validate', 'required']); ?>


			</div>

			<div class="input-field col s6">

			<?php echo Form::label('Orden:'); ?>


			<?php echo Form::text('orden', $producto->orden , ['class'=>'validate', 'required']); ?>


			</div>



		</div>

    	<div class="row">
				<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto_selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
						$band=0;
					?>
					<?php $__currentLoopData = $selects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($producto_selected->id == $sel->id_producto): ?>
							<?php
								$band++;
							?>
						<?php endif; ?>
      				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<p>
      				<?php if($band!=0): ?>
								<input type="checkbox" id="<?php echo e($producto_selected->id); ?>" name="producto_selected[]" value="<?php echo e($producto_selected->id); ?>" checked="checked" />
	  						<label for="<?php echo e($producto_selected->id); ?>"><?php echo e($producto_selected->titulo); ?></label>
      				<?php else: ?>
      					<input type="checkbox" id="<?php echo e($producto_selected->id); ?>" name="producto_selected[]" value="<?php echo e($producto_selected->id); ?>" />
	  						<label for="<?php echo e($producto_selected->id); ?>"><?php echo e($producto_selected->titulo); ?></label>
      				<?php endif; ?>

      		</p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

		<div class="col s12 no-padding">

			<?php echo Form::submit('Actualizar', ['class'=>'waves-effect waves-light btn right']); ?>


		</div>

		<?php echo Form::close(); ?>


		</div>

	</div>

</main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>