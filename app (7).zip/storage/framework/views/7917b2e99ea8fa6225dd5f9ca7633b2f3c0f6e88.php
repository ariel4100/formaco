
<?php $__env->startSection('titulo', 'Empresa'); ?>
<?php $__env->startSection('estilo'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/page/empresa.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/page/slider.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginas'); ?>
	<div class="container-fluid">
		<div id="carousel" class="carousel carousel-slider center" data-indicators="true" style="position: relative;">
		    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <div class="carousel-item white-text" href="" style="position: absolute;">
			      <img src="<?php echo e(asset($slider->imagen)); ?>" alt="">
			      <?php if($slider->titulo): ?>
			      	<div class="cont-titulos" style="    left: 31%;     top: 34%;">
				    	<div>
				    		<div class="titulo-slider " style="margin-bottom: 0;"><?php echo $slider->titulo; ?></div>
							<div class="subtitulo-slider "><?php echo $slider->subtitulo; ?></div>
				    		
				    	</div>
				    	
				    </div>
				   <?php endif; ?>
			    </div>
			    <div class="expand"><a href="#empresa"><i class="material-icons hide-on-small-only" style="color:white;">expand_more</i></a></div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

		

	</div>
	<div class="container-fluid" style="margin: 5% 10%;">
			<section class="row" style="margin-bottom: 4%; ">
				<div class="col s12 m4">
						<img class="responsive-img" src="<?php echo e(asset($nuestra->imagen)); ?>" width="100%;" alt="">
				</div>
				<div class="col s12 m8">
					<div class="subtitulo"><?php echo $nuestra->subtitulo; ?></div>
					<div class="titulo"><?php echo $nuestra->titulo; ?></div>
					<hr>
					<div class="contenido">
						<?php echo $nuestra->contenido; ?>

					</div>
				</div>

			</section>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.templates.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>