<?php $__env->startSection('titulo', 'Editar Buscador'); ?>



<?php $__env->startSection('contenido'); ?>



<main>

	<div class="container">

	    <?php if(count($errors) > 0): ?>

		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">

	  		<ul>

	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	  				<li><?php echo $error; ?></li>

	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  		</ul>

	  	</div>

		<?php endif; ?>

		<?php if(session('success')): ?>

		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">

			<?php echo e(session('success')); ?>


		</div>

		<?php endif; ?>



		<div class="row">

			<div class="col s12">

			<?php echo Form::model($buscador, ['route'=>['buscadores.update',$buscador->id], 'method'=>'PUT', 'files' => true]); ?>

				<div class="row">
					<div class="form-group col s12 pad-panel">
					  <?php echo Form::label('Tipo de opcion que desea crear:'); ?>

					  <select id="seccion" name="seccion">
					  	<?php if($buscador->seccion == 'flejar'): ?>
							<option value="flejar">¿Qué producto quiere flejar?</option>
							<option value="sistema">Sistema de flejado</option>
							<option value="tipo">Tipo de fleje</option>
							<option value="cantidad">Cantidad cada 24hs</option>
					  	<?php endif; ?>
						<?php if($buscador->seccion == 'sistema'): ?>
							<option value="sistema">Sistema de flejado</option>
							<option value="flejar">¿Qué producto quiere flejar?</option>
							<option value="tipo">Tipo de fleje</option>
							<option value="cantidad">Cantidad cada 24hs</option>
					  	<?php endif; ?>
					  	<?php if($buscador->seccion == 'tipo'): ?>
							<option value="tipo">Tipo de fleje</option>
							<option value="flejar">¿Qué producto quiere flejar?</option>
							<option value="sistema">Sistema de flejado</option>
							<option value="cantidad">Cantidad cada 24hs</option>
					  	<?php endif; ?>
					  	<?php if($buscador->seccion == 'cantidad'): ?>
							<option value="cantidad">Cantidad cada 24hs</option>
							<option value="flejar">¿Qué producto quiere flejar?</option>
							<option value="tipo">Tipo de fleje</option>
							<option value="sistema">Sistema de flejado</option>
					  	<?php endif; ?>
						</select>
					</div>

				</div>

				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('texto'); ?>

						<?php echo Form::text('texto', $buscador->texto , ['class'=>'validate', 'required']); ?>

					</div>
				</div>

				<div class="col s12 no-padding">

					<?php echo Form::submit('Actualizar', ['class'=>'waves-effect waves-light btn right']); ?>


				</div>

			<?php echo Form::close(); ?>


		</div>

		</div>

	</div>

</main>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>