

<?php $__env->startSection('titulo', 'Lista de trabajos'); ?>

<?php $__env->startSection('contenido'); ?>
<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
				<table class="highlight bordered">
					<thead>
						<td>Trabajo</td>
						<td>Imagen</td>
						<td>Orden</td>
						<td class="text-right">Acciones</td>
					</thead>
					<tbody>
					<?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($general->id == $imagen->id_generales): ?>
								<tr>
									<td><?php echo $general->titulo; ?></td>
									<td><img class="responsive-img" src="<?php echo e(asset($imagen->imagen)); ?>" alt=""></td>
									<td><?php echo $imagen->orden; ?></td>
									<td class="text-right">
										<a href="<?php echo e(route('galerias.edit',$imagen->id)); ?>"><i class="material-icons">create</i></a>
										<?php echo Form::open(['class'=>'en-linea', 'route'=>['galerias.destroy', $imagen->id], 'method' => 'DELETE']); ?>

											<button onclick='return confirm_delete(this);' type="submit" class="submit-button">
												<i class="material-icons red-text">cancel</i>
											</button>
										<?php echo Form::close(); ?>


									</td>
								</tr>
							<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
</main>
<script type="text/javascript" src="<?php echo e(asset('js/eliminar.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>