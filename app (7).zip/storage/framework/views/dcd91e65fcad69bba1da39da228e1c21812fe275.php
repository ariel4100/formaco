

<?php $__env->startSection('titulo', 'Editar sliders'); ?>

<?php $__env->startSection('contenido'); ?>
<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
				<table class="highlight bordered">
				<thead>
					<td>Link</td>
					<td>Logo</td>
					<td>Ubicacion</td>
					<td class="text-right">Acciones</td>
				</thead>
				<tbody>
				<?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($red->link); ?></td>
						<td><img src="<?php echo e(asset($red->logo)); ?>" alt=""></td>
						<td><?php echo e($red->ubicacion); ?></td>
						<td class="text-right">
							<a href="<?php echo e(route('redes.edit',$red->id)); ?>"><i class="material-icons">create</i></a>
							<?php echo Form::open(['class'=>'en-linea', 'route'=>['redes.destroy', $red->id], 'method' => 'DELETE']); ?>

								<button onclick='return confirm_delete(this);' type="submit" class="submit-button">
									<i class="material-icons red-text">cancel</i>
								</button>
							<?php echo Form::close(); ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>			
			</div>
		</div>
    </div>
</main>
<script type="text/javascript" src="<?php echo e(asset('js/eliminar.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>