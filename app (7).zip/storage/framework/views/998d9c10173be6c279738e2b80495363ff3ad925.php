<?php $__env->startSection('titulo', 'Editar producto'); ?>



<?php $__env->startSection('contenido'); ?>



<main>

	<div class="container">

	    <?php if(count($errors) > 0): ?>

		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">

	  		<ul>

	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	  				<li><?php echo $error; ?></li>

	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	  		</ul>

	  	</div>

		<?php endif; ?>

		<?php if(session('success')): ?>

		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">

			<?php echo e(session('success')); ?>


		</div>

		<?php endif; ?>



		<div class="row">

			<div class="col s12">

			<?php echo Form::open(['route'=>['subproducto.store'], 'method'=>'POST', 'files' => true]); ?>


       <?php echo e(csrf_field()); ?>


      <div class="row">

        <div class="form-group col-xs-12 pad-panel">

          <?php echo Form::label('Familia:'); ?>


          <?php echo Form::select('id_familia', $familias, null, ['class' => 'form-control']); ?>


        </div>

      </div>

			<div class="file-field input-field col s12">

				<div class="btn">

						<span>Imagen</span>

						<?php echo Form::file('imagen_destacada'); ?>


				</div>

				<div class="file-path-wrapper">

						<?php echo Form::text('imagen_destacada',null, ['class'=>'file-path validate', 'required']); ?>


				</div>

        </div>

        <div class="row">

          <div class="input-field col s6">

            <?php echo Form::label('Nombre:'); ?>


            <?php echo Form::text('titulo', null , ['class'=>'validate', 'required']); ?>


          </div>

          <div class="input-field col s6">

            <?php echo Form::label('Orden:'); ?>


            <?php echo Form::text('orden', null , ['class'=>'validate', 'required']); ?>


          </div>

          <div class="input-field col s6">

            <?php echo Form::label('Link de video:'); ?>


            <?php echo Form::text('link', null , ['class'=>'validate']); ?>


          </div>

        </div>

        <div class="row">

          <label class="col s12" for="parrafo">Contenido</label>

          <div class="input-field col s12">

            <?php echo Form::textarea('contenido', null, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>


          </div>

        </div>

        <div class="file-field input-field col s12">

	        <div class="btn">

				<span>Archivo para descarga</span>

				<?php echo Form::file('descarga'); ?>


			</div>

			<div class="file-path-wrapper">

				<?php echo Form::text('descarga',null, ['class'=>'file-path validate']); ?>


			</div>

        </div>
        <div class="row">

	        <div class="form-group col-xs-12 pad-panel">

	          <?php echo Form::label('Por cual fleje desea que sea buscado: '); ?>


	          <?php echo Form::select('flejar', $flejes, null, ['class' => 'form-control']); ?>


	        </div>

	      </div>
	      <div class="row">

	        <div class="form-group col-xs-12 pad-panel">

	          <?php echo Form::label('Por cual sistema de fleje desea que sea buscado: '); ?>


	          <?php echo Form::select('sistema', $sistema, null, ['class' => 'form-control']); ?>


	        </div>

	      </div>
		<div class="row">

	        <div class="form-group col-xs-12 pad-panel">

	          <?php echo Form::label('Por cual tipo de fleje desea que sea buscado: '); ?>


	          <?php echo Form::select('tipo', $tipo, null, ['class' => 'form-control']); ?>


	        </div>

	      </div>
      	<div class="row">

	        <div class="form-group col-xs-12 pad-panel">

	          <?php echo Form::label('Por qué cantidad de fleje desea que sea buscado? : '); ?>


	          <?php echo Form::select('cantidad', $cantidad, null, ['class' => 'form-control']); ?>


	        </div>

	      </div>



		<div class="col s12 no-padding">

			<?php echo Form::submit('Actualizar', ['class'=>'waves-effect waves-light btn right']); ?>


		</div>

		<?php echo Form::close(); ?>




		</div>

	</div>

</main>



<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>

<script>

	CKEDITOR.replace('contenido');

  CKEDITOR.replace('tabla');

	CKEDITOR.config.height = '150px';

	CKEDITOR.config.width = '100%';

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.cuerpo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>